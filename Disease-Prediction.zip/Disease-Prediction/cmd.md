 python manage.py makemigrations
 python manage.py migrate
 python manage.py runserver


https://www.kaggle.com/neelima98/disease-prediction-using-machine-learning

